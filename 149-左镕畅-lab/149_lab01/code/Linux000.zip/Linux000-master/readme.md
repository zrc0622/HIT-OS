# Linux 0.00

- `Linux000 code/` 目录下是源码，经修改后可编译成功。
- `windows` 下可直接运行 `Linux000.bat`
- `linux000_gui.bxrc` 是 `Bochs` 配置文件
- `Image` 是生成的 `Linux 0.00` 的二进制文件，被加载到软驱，由`Bochs` 从配置文件读取并启动执行。


by Dr. GuoJun LIU

Updated on 2020-03-26
